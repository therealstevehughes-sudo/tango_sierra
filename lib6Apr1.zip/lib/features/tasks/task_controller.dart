import 'task_model.dart';
import 'task_queue.dart';

class TaskController {
  int currentIndex = 0;
  final List<Task> tasks = TaskQueue.getTasks();

  Task getCurrentTask() => tasks[currentIndex];

  bool nextTask() {
    if (currentIndex < tasks.length - 1) {
      currentIndex++;
      return true;
    }
    return false;
  }
}
