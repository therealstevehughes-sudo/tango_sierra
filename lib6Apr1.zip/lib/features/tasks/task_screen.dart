import 'package:flutter/material.dart';
import 'task_controller.dart';
import 'task_model.dart';

class TaskScreen extends StatefulWidget {
  const TaskScreen({super.key});

  @override
  State<TaskScreen> createState() => _TaskScreenState();
}

class _TaskScreenState extends State<TaskScreen> {
  final TaskController controller = TaskController();

  final TextEditingController numberController = TextEditingController();
  final TextEditingController notesController = TextEditingController();

  String result = "PASS";

  bool correctiveDone = false;
  bool photoTaken = false;

  String? error;

  void validateAndSubmit() {
    Task task = controller.getCurrentTask();

    setState(() {
      error = null;
    });

    // VALIDATION
    if (task.requiresNumeric && numberController.text.isEmpty) {
      setState(() => error = "Numeric value required");
      return;
    }

    if (task.requiresNotes && notesController.text.isEmpty) {
      setState(() => error = "Notes required");
      return;
    }

    if (task.requiresPhoto && !photoTaken) {
      setState(() => error = "Photo required");
      return;
    }

    // CRITICAL FAIL LOGIC
    if (task.isCritical && result == "FAIL" && !correctiveDone) {
      setState(() => error = "Corrective action must be completed");
      return;
    }

    submitTask();
  }

  void submitTask() {
    final hasNext = controller.nextTask();

    if (hasNext) {
      setState(() {
        numberController.clear();
        notesController.clear();
        result = "PASS";
        correctiveDone = false;
        photoTaken = false;
        error = null;
      });
    } else {
      showDialog(
        context: context,
        builder: (_) => const AlertDialog(title: Text("All tasks complete")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    Task task = controller.getCurrentTask();

    return Scaffold(
      appBar: AppBar(title: const Text("Task")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text(task.title, style: const TextStyle(fontSize: 22)),

            const SizedBox(height: 20),

            if (task.requiresNumeric)
              TextField(
                controller: numberController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: "Enter value"),
              ),

            if (task.requiresNotes)
              TextField(
                controller: notesController,
                decoration: const InputDecoration(labelText: "Notes"),
              ),

            if (task.requiresPhoto)
              ElevatedButton(
                onPressed: () {
                  setState(() => photoTaken = true);
                },
                child: Text(photoTaken ? "Photo Added" : "Add Photo"),
              ),

            const SizedBox(height: 20),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () => setState(() => result = "PASS"),
                  child: const Text("PASS"),
                ),
                const SizedBox(width: 10),
                ElevatedButton(
                  onPressed: () => setState(() => result = "FAIL"),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                  child: const Text("FAIL"),
                ),
              ],
            ),

            const SizedBox(height: 20),

            if (task.isCritical && result == "FAIL")
              Column(
                children: [
                  Text(
                    "Corrective Action Required:\n${task.correctiveAction}",
                    style: const TextStyle(color: Colors.red),
                    textAlign: TextAlign.center,
                  ),
                  CheckboxListTile(
                    title: const Text("Corrective action completed"),
                    value: correctiveDone,
                    onChanged: (val) {
                      setState(() => correctiveDone = val ?? false);
                    },
                  ),
                ],
              ),

            if (error != null)
              Padding(
                padding: const EdgeInsets.all(8),
                child: Text(error!, style: const TextStyle(color: Colors.red)),
              ),

            const Spacer(),

            ElevatedButton(
              onPressed: validateAndSubmit,
              child: const Text("SUBMIT"),
            ),
          ],
        ),
      ),
    );
  }
}
